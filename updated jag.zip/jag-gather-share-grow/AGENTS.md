# Project development notes

## Architecture
- React + TanStack Start + TanStack Router.
- Vite builds the app; Nitro adapts the server output for Vercel.
- Supabase provides Auth, Postgres, Row Level Security, and private Storage.
- The GitHub repository is the source of truth; Vercel deploys from the connected branch.

## Security rules
- Use only `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` in browser code.
- Keep `SUPABASE_SECRET_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, database credentials, and cron secrets server-only.
- Never disable Row Level Security to make a query work. Fix the policy instead.
- Import `supabaseAdmin` only inside trusted server handlers/functions. It bypasses RLS.
- Validate server-function inputs and verify user identity before performing user-scoped operations.

## Development
- Keep route files under `src/routes` and allow the TanStack plugin to regenerate `src/routeTree.gen.ts`.
- Keep SQL migrations ordered under `drizzle/migrations`.
- Run `npm run typecheck`, `npm test`, and `npm run build` before merging significant changes.
