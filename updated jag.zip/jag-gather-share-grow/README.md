# JAG Students Association

A full-stack TanStack Start application using Supabase for authentication, Postgres data, and private media storage. It runs locally and deploys from GitHub to Vercel. There is no hosted-editor runtime or required editor account.

## Stack

- **Frontend:** React, TanStack Router, TanStack Start, Tailwind CSS
- **Backend:** TanStack Start server routes and server functions, deployed as Vercel Functions through Nitro
- **Database and authentication:** Supabase Postgres + Supabase Auth
- **Media:** Supabase Storage with private buckets and signed URLs
- **Source control and deployment:** GitHub → Vercel automatic deployments

## 1. Configure Supabase

1. Create or open a Supabase project.
2. Copy the **Project URL** and **Publishable key** from Project Settings → API Keys.
3. Create a **Secret key** in the same API Keys page. The app's phone-signup server function uses this key to create an account with the Admin Auth API. Keep this key server-side only. A legacy `service_role` key is also supported as `SUPABASE_SERVICE_ROLE_KEY`.
4. In Supabase → SQL Editor, run the SQL files in this exact order:
   - `drizzle/migrations/0000_jag_core.sql`
   - `drizzle/migrations/0001_jag_storage_policies.sql`
   - `drizzle/migrations/0002_restrict_post_featuring_and_role_lookup.sql`
   - `drizzle/migrations/0003_scope_public_interactions_and_media.sql`

   The second migration creates the private storage buckets and their access policies. Re-running the SQL files is not supported because the policy and trigger names are intentionally created once; use a fresh project or apply only missing steps for an existing database.

## 2. Add local environment variables

Copy `.env.example` to `.env` and paste your own values:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_public_key
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_public_key
SUPABASE_SECRET_KEY=sb_secret_your_server_secret_key
```

The `VITE_` values are sent to the browser and must contain **only** the Supabase URL and publishable key. Never put `SUPABASE_SECRET_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, database passwords, or other secrets in a `VITE_` variable or commit them to GitHub.

## 3. Run locally

Use Node.js 20 or newer:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. Check the backend connection at `/api/health`.

Useful commands:

```bash
npm run typecheck
npm test
npm run lint
npm run build
```

## 4. Push to GitHub

1. Create an empty GitHub repository.
2. From the project folder, run:

```bash
git init
git add .
git commit -m "Prepare JAG app for independent deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

The `.gitignore` excludes `.env` and other local secrets. Check `git status` before pushing and never force-add a local `.env` file.

## 5. Deploy on Vercel

1. In Vercel, choose **Add New → Project** and import the GitHub repository.
2. Keep the detected framework as **TanStack Start**. `vercel.json` declares the framework; Nitro creates the Vercel Functions build.
3. In Project → Settings → Environment Variables, add the values below for Production, Preview, and Development as needed:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
   - `SUPABASE_SECRET_KEY`
4. Deploy. Each push to the connected GitHub branch triggers a new deployment.
5. Visit `https://YOUR_VERCEL_DOMAIN/api/health`. A healthy response reports `ok: true` and `supabase: "connected"`.

After changing an environment variable in Vercel, redeploy so the new values are applied.

## Security model

- Browser code uses only the Supabase publishable key. Database access is restricted by the Row Level Security policies in the SQL migrations.
- `requireSupabaseAuth` verifies the signed-in user's bearer token before protected server functions run.
- `supabaseAdmin` is a server-only client that bypasses RLS. Use it only for trusted administrative tasks. Do not import `client.server.ts` from React components or browser-facing modules.
- Private Storage buckets issue signed URLs; uploaded objects are scoped to the authenticated user's folder.
- Secrets are read from environment variables and excluded from Git.

## Database migrations

The SQL migration files are the source of truth for the Supabase schema and policies. For optional Drizzle CLI operations, set `DATABASE_URL` (or `SUPABASE_DB_URL`) to a Postgres connection string from Supabase Project Settings → Database. Never commit a database connection string.

### Phone sign-up note

The current sign-up server function creates a phone account as confirmed without sending an SMS. This is convenient for a controlled launch, but it does **not** prove that the person owns the phone number. Before opening registration to the public, configure a Supabase SMS provider and change the onboarding flow to require a one-time verification code.

After the first successful `npm install`, keep the generated `package-lock.json` in GitHub. This makes future installations and Vercel builds repeatable.
