-- Create private buckets used by the application. Media is delivered through signed URLs.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('post-images', 'post-images', false, 10485760, array['image/jpeg', 'image/png', 'image/webp']),
  ('post-audio', 'post-audio', false, 52428800, array['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/wave', 'audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/ogg', 'audio/webm']),
  ('avatars', 'avatars', false, 10485760, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "JAG media readable" on storage.objects for select to anon, authenticated using (bucket_id in ('post-images','post-audio','avatars'));
create policy "JAG upload own folder" on storage.objects for insert to authenticated with check (bucket_id in ('post-images','post-audio','avatars') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "JAG update own files" on storage.objects for update to authenticated using (bucket_id in ('post-images','post-audio','avatars') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "JAG delete own files" on storage.objects for delete to authenticated using (bucket_id in ('post-images','post-audio','avatars') and (storage.foldername(name))[1] = auth.uid()::text);