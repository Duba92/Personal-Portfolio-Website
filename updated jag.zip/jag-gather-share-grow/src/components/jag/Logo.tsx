import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export const ORG_NAME = "Jatani Ali Generation (JAG) Students Association";

export function Logo({ className, inverted }: { className?: string; inverted?: boolean }) {
  return (
    <Link to="/" className={cn("inline-flex min-w-0 items-center gap-2.5", className)} aria-label="JAG home">
      <span
        aria-hidden="true"
        className={cn(
          "grid h-10 w-10 shrink-0 place-items-center rounded-full border-2 border-current font-display text-xs font-extrabold",
          inverted ? "text-primary-foreground" : "text-primary",
        )}
      >
        JAG
      </span>
      <span className="min-w-0 leading-tight">
        <span className={cn("block font-display text-xl font-extrabold", inverted ? "text-primary-foreground" : "text-primary")}>JAG</span>
        <span className={cn("hidden truncate text-[10px] font-medium sm:block", inverted ? "text-primary-foreground/70" : "text-muted-foreground")}>Jatani Ali Generation Students Association</span>
      </span>
    </Link>
  );
}
