import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";

const runtimeEnv = typeof process !== "undefined" ? process.env : {};
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || runtimeEnv.SUPABASE_URL;
const supabasePublishableKey =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || runtimeEnv.SUPABASE_PUBLISHABLE_KEY;

function createSupabaseFetch(apiKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );
    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }

    // New sb_publishable_* keys are opaque API keys, not JWT bearer tokens.
    if (apiKey.startsWith("sb_publishable_") && headers.get("Authorization") === `Bearer ${apiKey}`) {
      headers.delete("Authorization");
    }
    headers.set("apikey", apiKey);
    return fetch(input, { ...init, headers });
  };
}

function createSupabaseClient() {
  if (!supabaseUrl || !supabasePublishableKey) {
    const missing = [
      ...(!supabaseUrl ? ["VITE_SUPABASE_URL (or SUPABASE_URL)"] : []),
      ...(!supabasePublishableKey
        ? ["VITE_SUPABASE_PUBLISHABLE_KEY (or SUPABASE_PUBLISHABLE_KEY)"]
        : []),
    ];
    throw new Error(`Missing Supabase configuration: ${missing.join(", ")}`);
  }

  return createClient<Database>(supabaseUrl, supabasePublishableKey, {
    global: { fetch: createSupabaseFetch(supabasePublishableKey) },
    auth: {
      persistSession: typeof window !== "undefined",
      autoRefreshToken: typeof window !== "undefined",
      detectSessionInUrl: typeof window !== "undefined",
    },
  });
}

let client: ReturnType<typeof createSupabaseClient> | undefined;

// Lazy initialization keeps missing environment configuration from breaking
// unrelated server modules during import, while still failing clearly on use.
export const supabase = new Proxy({} as ReturnType<typeof createSupabaseClient>, {
  get(_target, property, receiver) {
    client ??= createSupabaseClient();
    return Reflect.get(client, property, receiver);
  },
});
