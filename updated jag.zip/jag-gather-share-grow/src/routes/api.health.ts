import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () => {
        const supabaseUrl = process.env.SUPABASE_URL;
        const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
        const adminKey = process.env.SUPABASE_SECRET_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY;
        const headers = { "cache-control": "no-store" };

        if (!supabaseUrl || !publishableKey) {
          return Response.json(
            { ok: false, service: "jag-backend", supabase: "not_configured" },
            { status: 503, headers },
          );
        }

        try {
          const response = await fetch(`${supabaseUrl.replace(/\/+$/, "")}/rest/v1/`, {
            headers: { apikey: publishableKey },
            signal: AbortSignal.timeout(5000),
          });

          if (!response.ok) {
            return Response.json(
              { ok: false, service: "jag-backend", supabase: "unreachable" },
              { status: 503, headers },
            );
          }

          return Response.json(
            {
              ok: true,
              service: "jag-backend",
              supabase: "connected",
              adminOperationsConfigured: Boolean(adminKey),
              timestamp: new Date().toISOString(),
            },
            { headers },
          );
        } catch {
          return Response.json(
            { ok: false, service: "jag-backend", supabase: "unreachable" },
            { status: 503, headers },
          );
        }
      },
    },
  },
});
