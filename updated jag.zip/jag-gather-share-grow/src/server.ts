import {
  createStartHandler,
  defaultStreamHandler,
  handleStartError,
} from "@tanstack/react-start/server";
import { createServerEntry } from "@tanstack/react-start/server-entry";

import "./lib/error-capture";
import { consumeLastCapturedError } from "./lib/error-capture";

const startHandler = createStartHandler(defaultStreamHandler);

// Use TanStack Start's standard fetch-entry contract. Nitro adapts this handler
// to Vercel Functions; the handler remains portable across supported runtimes.
export default createServerEntry({
  async fetch(request, options) {
    try {
      return await startHandler(request, options);
    } catch (error) {
      console.error(consumeLastCapturedError() ?? error);
      return handleStartError(error);
    }
  },
});
