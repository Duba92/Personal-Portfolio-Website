import { supabase } from "@/integrations/supabase/client";

/** Uploaded files are stored as "storage:<bucket>/<path>"; external URLs are used as-is. */
export const STORAGE_PREFIX = "storage:";

const cache = new Map<string, { url: string; exp: number }>();

export async function resolveMediaUrl(ref: string | null | undefined): Promise<string | null> {
  if (!ref) return null;
  if (!ref.startsWith(STORAGE_PREFIX)) return ref;
  const hit = cache.get(ref);
  if (hit && hit.exp > Date.now()) return hit.url;
  const rest = ref.slice(STORAGE_PREFIX.length);
  const slash = rest.indexOf("/");
  const bucket = rest.slice(0, slash);
  const path = rest.slice(slash + 1);
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60 * 6);
  if (!data?.signedUrl) return null;
  cache.set(ref, { url: data.signedUrl, exp: Date.now() + 1000 * 60 * 60 * 5 });
  return data.signedUrl;
}

export async function uploadFile(bucket: string, userId: string, file: File | Blob, name: string) {
  const ext = name.split(".").pop() || "bin";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    contentType: (file as File).type || undefined,
    upsert: false,
  });
  if (error) throw error;
  return { ref: `${STORAGE_PREFIX}${bucket}/${path}`, bucket, path };
}
