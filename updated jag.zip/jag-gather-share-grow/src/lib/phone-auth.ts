/** Local Ethiopian numbers and international numbers use the same login identity. */
export function toE164(raw: string) {
  const digits = raw.replace(/\D/g, "");
  if (raw.trim().startsWith("+")) return `+${digits}`;
  if (digits.startsWith("251")) return `+${digits}`;
  return `+251${digits.startsWith("0") ? digits.slice(1) : digits}`;
}

export function phoneCredentials(phone: string, password: string) {
  const normalized = toE164(phone);
  if (!/^\+[1-9]\d{7,14}$/.test(normalized)) throw new Error("Enter a valid phone number.");
  return { phone: normalized, password };
}

export function signupCredentials(fullName: string, phone: string, password: string) {
  const name = fullName.trim();
  if (!name) throw new Error("Enter your full name.");
  return { ...phoneCredentials(phone, password), options: { data: { full_name: name } } };
}