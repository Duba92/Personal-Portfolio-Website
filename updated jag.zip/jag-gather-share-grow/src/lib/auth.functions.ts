import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  fullName: z.string().trim().min(2).max(100),
  phone: z.string().regex(/^\+[1-9]\d{7,14}$/),
  password: z.string().min(8).max(72),
});

/** Creates a phone + password account without sending an SMS code. */
export const registerPhoneUser = createServerFn({ method: "POST" })
  .inputValidator((input) => schema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.createUser({
      phone: data.phone,
      password: data.password,
      phone_confirm: true,
      user_metadata: { full_name: data.fullName },
    });
    if (!error) return { ok: true as const };
    const msg = error.message;
    if (/already|registered|exists/i.test(msg)) return { ok: false as const, error: "This phone number already has an account. Please sign in." };
    if (/weak|guess|password/i.test(msg)) return { ok: false as const, error: "That password is too easy to guess. Please choose a stronger one." };
    console.error("registerPhoneUser failed", msg);
    return { ok: false as const, error: "We couldn't create your account. Please try again." };
  });
