# JAG roadmap

## Reported issues
- [x] Update vulnerable dependencies and verify locked versions, tests, and app build
- [x] Fix the logo URL for external hosting, including Vercel
- [x] Explain disabled phone registration without promising a temporary outage
- [ ] Complete phone signup/sign-in verification (blocked: owner must enable Phone in Auth settings and configure SMS delivery)

## Phase 1 — core (done)
- [x] Join form with full name, phone and password; phone/password sign-in form and tests
- [ ] Activate phone accounts and verify real signup/sign-in (blocked: phone provider disabled; SMS provider needed in Auth settings)
- [x] Remove all sample posts and attached media
- [x] Apply logo-inspired colors and make banner text/photo fit phones
- [x] Brand, home, Explore, Experiences, About
- [x] Phone/password sign-in forms, profile setup, public profiles, follow
- [x] Mixed-media posts (rich text, photos, audio upload/record, YouTube), drafts, edit/delete
- [x] Likes, bookmarks, comments with replies, share, view counts, live notifications

## Phase 2 — next
- [ ] Student Guides library
- [ ] Questions & Answers
- [ ] Opportunities
- [ ] Community page
- [ ] Admin dashboard + reports/moderation
- [x] Afaan Oromo as default language with English toggle (hero, nav, footer, auth)
- [ ] Amharic translations, dark mode, translate remaining pages (explore, post, profile, settings)
- [ ] Turn on SMS for phone sign-in (needs an SMS provider in Auth settings — user action)
